<?php 
include('simple_html_dom.php');

$html = file_get_html('http://sv2.ut.edu.vn/XemDiem.aspx?mssv=1451120161');
echo $html;
$title = array();

foreach($html->find('table[class="grid grid-color2 tblKetQuaHocTap"]') as $element) 
{

	foreach($element->find('th') as $e)
		array_push($title, $e->innertext);
}
echo '<pre>', print_r($title), '</pre>';


foreach($html->find('table[class="grid grid-color2 tblKetQuaHocTap"]') as $element) 
{

	foreach($element->find('tr') as $tr)
	{
		$b = array();
		foreach ($tr->find('td') as $value) {
			array_push($b, trim($value->innertext));
		}
		if(count($b) > 2)
		{
			// echo '<pre>', print_r($b), '</pre> <br>';
			$json_encoded = json_encode($b, JSON_UNESCAPED_UNICODE);
			echo 'JSON ENCODE  ', $json_encoded ,'<br>';
			echo 'JSON DECODE  <pre>', var_dump(json_decode($json_encoded, true)), ' </pre><br>';
			$cnt = count(var_dump(json_decode($json_encoded, true)));
			echo "Tên Học Phần: ". $b[2]. '<br>';
			echo "Số cột: ".$cnt .'<br>';
		}

	}
}
?>